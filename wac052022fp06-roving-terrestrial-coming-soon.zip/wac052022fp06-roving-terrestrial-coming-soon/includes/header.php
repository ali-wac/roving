<!doctype html>
  <html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/main.min.css">
    <title>Roving Terrestrail</title>
  </head>
  <body>
  <header class="main-header">
        <div class="container h-100 d-flx flx-vcenter">
            <div class="logo">
                <span class="link">
                    <img src="assets/images/roving-logo.png" alt="roving" srcset="">
                </a>
            </div>
            <div class="header-right ml-auto d-flx flx-vcenter">
                <nav class="main-nav">
                    <ul>
                        <li><span class="link">ARTIST</a>
                            <ul>
                                <li><span class="link">Services 2</a></li>
                                <li><span class="link">Services 3</a></li>
                            </ul>
                        </li>
                        <li><span class="link">Sign in</a></li>
                        <li>
                            <span class="link">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="20.609" viewBox="0 0 16 20.609">
                                <g id="Group_34" data-name="Group 34" transform="translate(-1558 -31.391)">
                                    <g id="Rectangle_1" data-name="Rectangle 1" transform="translate(1558 37)" fill="none" stroke="#fff" stroke-width="1">
                                    <rect width="16" height="15" stroke="none"/>
                                    <rect x="0.5" y="0.5" width="15" height="14" fill="none"/>
                                    </g>
                                    <path id="Path_1" data-name="Path 1" d="M1561.1,41.5V34.184s.655-2.293,4.689-2.293c3.773,0,4.738,2.293,4.738,2.293V41.5" transform="translate(0.401)" fill="none" stroke="#fff" stroke-width="1"/>
                                </g>
                                </svg>

                                Cart(0)
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
        <div class="mob-btn">
			<span></span>
			<span></span>
			<span></span>
	    </div>
	    <div class="overlay"></div>	
    </header>   
   