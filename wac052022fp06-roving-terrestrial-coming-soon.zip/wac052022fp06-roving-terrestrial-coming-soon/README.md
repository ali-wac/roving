Boiler Plate for all web-based-application 
Forked BRANCH